var name = Black Panther
var year = 2018
var gross = Int(1.3)

print ("My movie is \"Black Panther\". Black Panther came out in 2018. It has a worldwide Gross of 1.3 Billion Dollars ") 
// print ("Black Panther came out in \"2018\" ")
